#!/usr/bin/env python3
"""
Script to fix mobile hamburger menu using the provided working solution
"""

import re

def fix_mobile_menu(file_path):
    """Fix mobile menu in the given HTML file"""
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 1. First, fix the hamburger button - make it simpler and add proper attributes
    old_button = r'<button id="mobile-menu-button" class="text-gray-700 hover:text-energy-green focus:outline-none focus:text-energy-green"><i class="fas fa-bars text-xl"></i></button>'
    new_button = '<button id="menuBtn" aria-controls="mobileMenu" aria-expanded="false" aria-label="Menu" class="text-gray-700 hover:text-energy-green focus:outline-none focus:text-energy-green"><i class="fas fa-bars text-xl"></i></button>'
    
    content = content.replace(old_button, new_button)
    
    # 2. Replace the complex mobile menu with a simpler, working version
    # Find the existing mobile menu div and replace it entirely
    mobile_menu_pattern = r'<div id="mobile-menu"[^>]*>.*?</div></div></nav>'
    
    new_mobile_menu = '''<nav id="mobileMenu" hidden class="mobile-menu-nav">
    <a href="/" class="mobile-menu-link">Home</a>
    <a href="/vergelijken" class="mobile-menu-link">Vergelijken</a>
    <a href="/kopen" class="mobile-menu-link">Kopen</a>
    <a href="/kosten" class="mobile-menu-link">Kosten</a>
    <a href="/subsidie" class="mobile-menu-link">Subsidie</a>
    <div class="mobile-menu-section">
        <div class="mobile-menu-section-title">Gidsen</div>
        <a href="/gids/kopers-gids" class="mobile-menu-sublink"><i class="fas fa-book mr-2"></i>Complete Kopers Gids</a>
        <a href="/gids/installatie" class="mobile-menu-sublink"><i class="fas fa-tools mr-2"></i>Installatie Handleiding</a>
        <a href="/gids/onderhoud-garantie" class="mobile-menu-sublink"><i class="fas fa-shield-alt mr-2"></i>Onderhoud & Garantie</a>
        <a href="/gids/besparing-maximaliseren" class="mobile-menu-sublink"><i class="fas fa-chart-line mr-2"></i>Besparing Maximaliseren</a>
    </div>
    <a href="/blog" class="mobile-menu-link">Blog</a>
    <a href="/faq" class="mobile-menu-link">FAQ</a>
</nav></div></div></nav>'''
    
    content = re.sub(mobile_menu_pattern, new_mobile_menu, content, flags=re.DOTALL)
    
    # 3. Add CSS for the mobile menu (insert after the existing TailwindCSS config)
    css_insertion_point = r'(</script><link href="https://cdn\.jsdelivr\.net/npm/@fortawesome/fontawesome-free@6\.4\.0/css/all\.min\.css" rel="stylesheet"/>)'
    
    mobile_css = '''<style>
/* Mobile Menu Styles */
#mobileMenu {
  position: fixed; 
  top: 64px; 
  left: 0; 
  right: 0;
  background: #fff; 
  padding: 16px; 
  z-index: 1000;
  box-shadow: 0 6px 20px rgba(0,0,0,.08);
  border-top: 1px solid #e5e7eb;
}

.mobile-menu-nav {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.mobile-menu-link {
  display: block;
  padding: 12px 16px;
  color: #374151;
  font-weight: 500;
  text-decoration: none;
  border-radius: 8px;
  transition: all 0.2s;
}

.mobile-menu-link:hover {
  background-color: #f3f4f6;
  color: #10b981;
}

.mobile-menu-section {
  padding: 8px 0;
  border-top: 1px solid #e5e7eb;
  border-bottom: 1px solid #e5e7eb;
  margin: 8px 0;
}

.mobile-menu-section-title {
  font-size: 14px;
  font-weight: 600;
  color: #6b7280;
  text-transform: uppercase;
  margin-bottom: 8px;
  padding: 0 16px;
}

.mobile-menu-sublink {
  display: block;
  padding: 8px 24px;
  color: #4b5563;
  font-size: 14px;
  text-decoration: none;
  border-radius: 6px;
  transition: all 0.2s;
}

.mobile-menu-sublink:hover {
  background-color: #f3f4f6;
  color: #10b981;
}

/* Header positioning */
nav.bg-white {
  position: relative; 
  z-index: 1001;
}

/* Hide menu on desktop */
@media (min-width: 768px) {
  #mobileMenu { 
    display: none !important; 
  }
}
</style>'''
    
    replacement = mobile_css + r'\1'
    content = re.sub(css_insertion_point, replacement, content)
    
    # 4. Replace the JavaScript with the working solution
    # Find and replace the existing mobile menu script
    js_pattern = r'// Mobile menu toggle - Enhanced.*?(?=</script>|$)'
    
    new_js = '''// Mobile Menu Toggle - Working Solution
(function () {
  var btn = document.getElementById('menuBtn');
  var menu = document.getElementById('mobileMenu');
  if (!btn || !menu) return;

  btn.addEventListener('click', function () {
    var open = menu.hasAttribute('hidden');
    if (open) {
      menu.removeAttribute('hidden');
      btn.setAttribute('aria-expanded', 'true');
      document.body.style.overflow = 'hidden';   // scroll-lock
    } else {
      menu.setAttribute('hidden', '');
      btn.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    }
  });

  // Close menu when clicking outside
  document.addEventListener('click', function(e) {
    if (!btn.contains(e.target) && !menu.contains(e.target)) {
      menu.setAttribute('hidden', '');
      btn.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    }
  });

  // Close menu on escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && !menu.hasAttribute('hidden')) {
      menu.setAttribute('hidden', '');
      btn.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    }
  });
})();'''
    
    content = re.sub(js_pattern, new_js, content, flags=re.DOTALL)
    
    return content

# Fix mobile menu in index.html and other main pages
files_to_fix = [
    '/home/user/webapp/index.html',
    '/home/user/webapp/vergelijken.html',
    '/home/user/webapp/kopen.html'
]

print("🔧 Fixing mobile hamburger menu...")

fixed_count = 0
for file_path in files_to_fix:
    try:
        fixed_content = fix_mobile_menu(file_path)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(fixed_content)
        print(f"✅ Fixed mobile menu in {file_path}")
        fixed_count += 1
    except FileNotFoundError:
        print(f"⚠️ File not found: {file_path}")
    except Exception as e:
        print(f"❌ Error fixing {file_path}: {e}")

print(f"\n🎉 Successfully fixed mobile menu in {fixed_count} files!")
print("📱 Mobile hamburger menu should now work properly!")
print("\nFeatures added:")
print("✅ Proper button attributes (aria-controls, aria-expanded)")
print("✅ Working toggle functionality")
print("✅ Click-outside-to-close")
print("✅ Escape key to close")
print("✅ Scroll lock when menu is open")
print("✅ Proper CSS positioning and styling")